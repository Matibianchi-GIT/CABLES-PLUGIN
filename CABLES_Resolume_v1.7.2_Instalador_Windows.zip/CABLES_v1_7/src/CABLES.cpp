// CABLES v1.7.2 - correccion de inclusiones Windows SDK / WIC.
// Copyright (c) 2026. Codigo del plugin creado para este proyecto.
// SDK externo: https://github.com/resolume/ffgl (BSD-3-Clause).
//
// IMPORTANTE: FFGL.h incluye windows.h con NOMSG, NOUSER y NONLS, entre
// otras macros de exclusion. Si se incluye FFGLSDK.h primero, Windows.h
// queda protegido por sus include guards y despues WIC carece de MSG/LPMSG,
// CP_UTF8 y MultiByteToWideChar. Cargar la API completa de Windows PRIMERO.
#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wincodec.h>
#include <wrl/client.h>
#endif
#include <FFGLSDK.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cwchar>
#include <utility>
#include <string>
#include <vector>
#include <filesystem>
#include <cstdint>

using namespace ffglex;

namespace {
constexpr int kSides = 6;
constexpr int kSegments = 88;
constexpr int kVerticesPerCable = kSides * kSegments * 6;
enum Param : unsigned int {
    P_CABLE_COUNT=0, P_CHAOS,
    P_LENGTH, P_SPREAD, P_THICKNESS, P_BUNCH, P_SLACK,
    P_ZOOM, P_RELEASE, P_SPHERE_DIAMETER,
    P_ROT_X, P_ROT_Y, P_ROT_Z,
    P_LIGHT_MODE, P_LIGHT_SPEED, P_LIGHT_POWER,
    P_ERR_AMOUNT, P_ERR_SPEED, P_ERR_JITTER,
    P_ERR_SPREAD, P_ERR_RANDOMNESS, P_ERR_SHARPNESS,
    P_ENV_FOLDER, P_ENV_SELECT, P_ENV_STRENGTH,
    P_COUNT
};

const char* kVertexShader = R"GLSL(#version 410 core
// CABLES v1.7.0 — stable cable IDs; anchored fBm turbulence; XYZ scene rotation.
uniform float uTime;
uniform float uZoom;
uniform float uSpread;
uniform float uThickness; // 0..1 maps original tube radius up to 5x
uniform float uRelease;
uniform float uSphereDiameter; // 0..3.0; zero collapses entire released structure
uniform float uAngleX;     // accumulated radians, continuous across slider changes
uniform float uAngleY;
uniform float uAngleZ;
uniform float uLength;     // 0..1; zero hides ALL cable geometry
uniform float uChaos; // moving noise amplitude 0..1
uniform float uBunch;
uniform float uSlack;
uniform vec2 uResolution;
// Motion Mode is permanently Vibrate (1), with additional Erratic deformation active.
uniform float uErrAmount;
uniform float uErrSpeed;
uniform float uErrJitter;
uniform float uErrSpread;
uniform float uErrRandomness;
uniform float uErrSharpness;

out vec3 vNormal;
out vec3 vWorld;
out float vAlong;
out float vCable;

const float PI = 3.141592653589793;
const float TAU = 6.283185307179586;
const int SEG = 88;
const int SIDES = 6;
const float GOLDEN = 0.618033988749895;  // low-discrepancy distribution, independent of visible count
float hash1(float x) { return fract(sin(x*91.371)*47583.279); }

// Fast vector value noise: 3 independent channels, trilinearly interpolated.
// Coordinates contain persistent cable IDs, NOT the currently visible cable count.
vec3 hash33(vec3 p) {
    p=fract(p*vec3(.1031,.1030,.0973));
    p+=dot(p,p.yxz+33.33);
    return fract((p.xxy+p.yzz)*p.zyx);
}
vec3 valueNoise3(vec3 p) {
    vec3 i=floor(p), f=fract(p);
    f=f*f*(3.0-2.0*f);
    vec3 a=mix(hash33(i+vec3(0,0,0)),hash33(i+vec3(1,0,0)),f.x);
    vec3 b=mix(hash33(i+vec3(0,1,0)),hash33(i+vec3(1,1,0)),f.x);
    vec3 c=mix(hash33(i+vec3(0,0,1)),hash33(i+vec3(1,0,1)),f.x);
    vec3 d=mix(hash33(i+vec3(0,1,1)),hash33(i+vec3(1,1,1)),f.x);
    return mix(mix(a,b,f.y),mix(c,d,f.y),f.z)*2.0-1.0;
}
vec3 turbulence3(vec3 p) {
    // Two spatial frequencies generate different irregularities on each span.
    return .74*valueNoise3(p)+.26*valueNoise3(p*2.63+vec3(11.7,3.1,7.9));
}

vec3 rawAnchor(float id, int node) {
    // STABLE: IDs from 0..79 always map to the same points regardless of Quantity.
    // Additions are appended; no normalization by the current count.
    float q=fract((id+.5)*GOLDEN);
    float group=floor(id/6.0);
    float s=float(node);
    float span=mix(.42,1.70,uSpread);
    float cluster=(hash1(group*1.37+1.3)*2.0-1.0)*span;
    float ranked=(q*2.0-1.0)*span;
    float central=mix(ranked,cluster,uBunch*.77);
    float variation=hash1(id*3.731+s*17.713)-.5;
    float bundleWalk=(hash1(group*2.71+s*3.38)-.5)*.62*.70;
    float lateral=(hash1(id*1.331+s*9.191)-.5)*(.10+.78*.62);
    float xs=central+variation*(.1+uBunch*.12)+bundleWalk+lateral*(s>0.0?1.0:.27);
    float ys=1.30-s*.47+(hash1(id*2.93+s*6.23)-.5)*(.08+.22*.62);
    float zs=(hash1(group*.737+s*1.71)-.5)*.37+variation*(.08+.26*.62);
    if(node==4){
        // Full-length free tail; uLength controls the *visible fraction* of all spans.
        ys=-1.86+variation*.33;
        xs+=(hash1(id*4.97+14.0)-.5)*(.13+.75*.62);
        zs+=(hash1(id*7.73+15.0)-.5)*.34;
    }
    return vec3(xs,ys,zs);
}
vec3 anchor(float id, int node) {
    vec3 anchored=rawAnchor(id,node);
    if(node<=0 || node>=4) return anchored;
    vec3 top=rawAnchor(id,0),end=rawAnchor(id,4);
    float progress=float(node)*.25;
    vec3 fallback=mix(top,end,progress);
    // Anclajes = 0 fijo: los nodos intermedios siguen la linea superior-inferior.
    float influence=0.0;
    return mix(fallback,anchored,influence);
}
vec3 cableNetwork(float u, float id) {
    float scaled=clamp(u,0.0,1.0)*4.0;
    int seg=min(int(floor(scaled)),3);
    float t=scaled-float(seg);
    vec3 a=anchor(id,seg),b=anchor(id,seg+1);
    vec3 prev=anchor(id,max(seg-1,0)),next=anchor(id,min(seg+2,4));
    vec3 ta=(b-prev)*.42,tb=(next-a)*.42;
    float t2=t*t,t3=t2*t;
    vec3 p=(2.0*t3-3.0*t2+1.0)*a+(t3-2.0*t2+t)*ta
          +(-2.0*t3+3.0*t2)*b+(t3-t2)*tb;
    // Every intermediate anchor is fixed. Noise and vibration taper to exactly
    // zero at both ends of each individual segment.
    float envelope=sin(PI*t);
    float irregular=hash1(id*4.63+float(seg)*13.1);
    float sag=(.01+.47*uSlack)*(.34+irregular*.95);
    p.y-=envelope*sag;
    // Noise + Jitter + Sinusoide: los TRES se aplican siempre.
    // Caos amplitud conserva el control de la intensidad conjunta (0 desactiva amplitud).
    // La envolvente fija la deformacion a cero en los extremos de cada tramo.
    float phase=uTime*(0.38+hash1(id*2.13)*0.32);
    vec3 np=vec3(u*8.7+id*0.31,float(seg)*2.7+id*.07,phase);
    vec3 motion=turbulence3(np)*.92;
    float tick=floor(uTime*(7.0+17.0*hash1(id*5.7)));
    float knot=floor(t*9.0);
    motion+=(hash33(vec3(id*13.7+tick*1.93,knot*3.31,float(seg)*6.13))*2.0-1.0)*.75;
    float rate=1.2+hash1(id*1.17)*2.4;
    motion+=vec3(sin(uTime*rate+u*19.0+id),
                 sin(uTime*rate*.79+u*13.0+id*2.13),
                 sin(uTime*rate*1.37+u*17.0+id*5.71))*.68;
    p+=envelope*uChaos*motion;
    // Unpredictable wire loops at high Chaos settings.
    float loopMask=step(.47,irregular);
    float loopR=loopMask*(.06+.22*uSlack)*envelope;
    p.x+=loopR*(cos(TAU*t)-1.0)*.7;
    p.y+=loopR*sin(TAU*t);
    // Modo Vibrate fijo: vibracion orgánica sin selector de modo.
    // Los parametros Erratic siguen disponibles e independientes del modo fijo.
    float amp=(.008+.065*uErrAmount)*envelope;
    float vibrateRate=.6+5.0*uErrSpeed;
    p.x+=amp*sin(uTime*vibrateRate+u*11.0+id*.38);
    p.z+=amp*sin(uTime*vibrateRate*1.37+u*8.9+id*.27);
    return p;
}
vec3 rotateXYZ(vec3 p) {
    float x=cos(uAngleX),sx=sin(uAngleX);
    float y=cos(uAngleY),sy=sin(uAngleY);
    float z=cos(uAngleZ),sz=sin(uAngleZ);
    p=vec3(p.x,x*p.y-sx*p.z,sx*p.y+x*p.z);
    p=vec3(y*p.x+sy*p.z,p.y,-sy*p.x+y*p.z);
    p=vec3(z*p.x-sz*p.y,sz*p.x+z*p.y,p.z);
    return p;
}
vec3 cableSphere(float u,float id) {
    float q=fract((id+.5)*GOLDEN); // stable distribution at every count
    float theta=.16+(PI-.32)*u;
    float phi=q*TAU+uChaos*.35*sin(u*TAU*1.7+id*1.13);
    float radius=.86+uChaos*.12*sin(u*15.0+id*3.2)+uSlack*.05*sin(u*TAU*4.0+id);
    radius+=uErrAmount*.035*sin(uTime*2.1+u*27.0+id);
    // This is a geometry scale, not a camera zoom: only the sphere size changes.
    // Rotation is applied once after the network/sphere blend, in both modes.
    return uSphereDiameter*vec3(radius*sin(theta)*cos(phi),radius*cos(theta),radius*sin(theta)*sin(phi));
}
// Erratic movement: time-continuous random poses with angular interpolation.
// No dependencies on the active cable count. Every knot has a stable ID.
vec3 randomDirection(float key) {
    return vec3(hash1(key+1.31),hash1(key+19.71),hash1(key+53.13))*2.0-1.0;
}
vec3 erraticKnot(float id, int span, int node, int maxNode, float timePhase) {
    if(node<=0 || node>=maxNode) return vec3(0.0);
    float tick=floor(timePhase);
    float phase=fract(timePhase);
    // High Sharpness produces long holds followed by brief violent moves.
    float transition=smoothstep(mix(.08,.78,uErrSharpness),.997,phase);
    float key=id*173.31+float(span)*39.17+float(node)*8.57;
    vec3 previous=randomDirection(key+tick*211.73);
    vec3 next=randomDirection(key+(tick+1.0)*211.73);
    return mix(previous,next,transition);
}
vec3 erraticOffset(float along, float id, float released) {
    // Erratic parameters are active in ALL four motion modes.
    if(uErrAmount<=.00001) return vec3(0.0);
    float phaseAlong=clamp(along,0.0,.999999)*4.0;
    int span=int(floor(phaseAlong));
    float local=fract(phaseAlong);
    const int nodeCount=9; // Erratic Bend fijo en 1.0 (maximo)
    float knotPosition=local*float(nodeCount);
    int a=min(int(floor(knotPosition)),nodeCount-1);
    float alpha=fract(knotPosition);
    float speed=mix(.12,4.5,uErrSpeed);
    float perCable=mix(1.0,.55+1.05*hash1(id*7.711+2.7),uErrRandomness);
    float timePhase=uTime*speed*perCable+id*4.17*uErrRandomness;
    vec3 k0=erraticKnot(id,span,a-1,nodeCount,timePhase);
    vec3 k1=erraticKnot(id,span,a,nodeCount,timePhase);
    vec3 k2=erraticKnot(id,span,a+1,nodeCount,timePhase);
    vec3 k3=erraticKnot(id,span,a+2,nodeCount,timePhase);
    vec3 angular=mix(k1,k2,alpha);
    float f2=alpha*alpha,f3=f2*alpha;
    vec3 curved=.5*((2.0*k1)+(-k0+k2)*alpha+
        (2.0*k0-5.0*k1+4.0*k2-k3)*f2+(-k0+3.0*k1-3.0*k2+k3)*f3);
    vec3 shape=mix(curved,angular,uErrSharpness);
    // Scaled envelope guarantees pinning at every intermediary anchor in network mode.
    float pinned=smoothstep(0.0,.08,local)*smoothstep(0.0,.08,1.0-local);
    float pinWeight=mix(pinned,1.0,clamp(released,0.0,1.0));
    float range=uErrAmount*mix(.075,1.80,uErrSpread)*pinWeight;
    vec3 displacement=shape*range;

    // Micro-jitter: three incommensurate frequencies, unique per cable.
    float jitterRate=mix(8.0,43.0,uErrSpeed);
    vec3 rapid=vec3(
        sin(uTime*jitterRate*(.78+hash1(id*3.0))+along*51.7+id*7.1),
        sin(uTime*jitterRate*(1.08+hash1(id*3.1))+along*68.3+id*3.9),
        sin(uTime*jitterRate*(1.37+hash1(id*3.2))+along*43.9+id*9.3));
    displacement+=rapid*(.095*uErrAmount*uErrJitter*pinWeight);

    return displacement;
}

vec3 cablePoint(float u,float id) {
    // Extent control: 0 => no cable; 1 => full anchored/spherical length.
    // The generator ALWAYS references the same full-length spline.
    // Crecimiento fijo desde el CENTRO: tramo visible [0.5-L/2, 0.5+L/2].
    // Largo 0 oculta los tubos; Largo 1 revela la curva completa.
    // Los IDs y puntos originales nunca dependen de Largo ni Cantidad.
    float normalizedU=clamp(u,0.0,1.0);
    float visibleU=0.5+(normalizedU-0.5)*uLength;
    vec3 anchored=cableNetwork(visibleU,id);
    // 0 = ungrouped, 1 = cable network fully gathered on the local central axis.
    anchored.xz *= 1.0-uBunch;
    vec3 sphere=cableSphere(visibleU,id);
    // Trailing ends free before middle anchors, upper anchors release last.
    float freeTail=(1.0-visibleU)*.20;
    float localRelease=smoothstep(0.0,.80,clamp(uRelease-freeTail,0.0,1.0));
    vec3 result=mix(anchored,sphere,localRelease);
    // Apply erratic motion after the network-to-sphere blend, keeping IDs fixed.
    // Single XYZ transform for network, sphere and transition, including jitter.
    // Keep raw anchor coordinates and cable IDs untouched by the rotation.
    // The erratic offsets must contract with the spherical formation,
    // otherwise Diameter=0 still leaves animated cables visible.
    float sphericalScale=mix(1.0,clamp(uSphereDiameter,0.0,1.0),localRelease);
    return rotateXYZ(result+erraticOffset(visibleU,id,localRelease)*sphericalScale);
}
void main() {
    int quadIndex=gl_VertexID/6;
    int tri=gl_VertexID%6;
    int segment=quadIndex/SIDES;
    int side=quadIndex%SIDES;
    int du=(tri==1||tri==4||tri==5)?1:0;
    int dv=(tri==2||tri==3||tri==5)?1:0;
    float along=float(segment+du)/float(SEG);
    float angle=float(side+dv)/float(SIDES)*TAU;
    float id=float(gl_InstanceID);
    // Zero is genuinely empty, not tiny tubes or remaining hanging tails.
    if(uLength<=.00001 || (uRelease>=.999999 && uSphereDiameter<=.000001)){
        gl_Position=vec4(3.0,3.0,0.0,1.0);
        vNormal=vec3(0,0,1);vWorld=vec3(0);vAlong=along;vCable=id;
        return;
    }
    vec3 p=cablePoint(along,id);
    float d=.0018;
    vec3 p0=cablePoint(max(0.0,along-d),id);
    vec3 p1=cablePoint(min(1.0,along+d),id);
    vec3 tangent=normalize(p1-p0+vec3(.000001));
    vec3 axis=cross(tangent,vec3(0,0,1));
    if(dot(axis,axis)<.000001)axis=vec3(1,0,0);
    axis=normalize(axis);
    vec3 second=normalize(cross(tangent,axis));
    vec3 normal=cos(angle)*axis+sin(angle)*second;
    float releaseOfPoint=smoothstep(0.0,.80,clamp(uRelease-(1.0-along)*.20,0.0,1.0));
    float sphereScale=mix(1.0,clamp(uSphereDiameter,0.0,1.0),releaseOfPoint);
    float radius=mix(.0022,.0205,uThickness*uThickness)*mix(1.0,5.0,uThickness)*smoothstep(0.0,.012,uLength)*sphereScale;
    vec3 world=p+normal*radius;
    float cameraZ=mix(3.90,0.38,uZoom);
    float distanceToEye=cameraZ-world.z;
    if(distanceToEye<=0.10){
        gl_Position=vec4(3.0,3.0,0.0,1.0);
        vNormal=normal;vWorld=world;vAlong=along;vCable=id;return;
    }
    float focal=3.55/distanceToEye;
    float aspect=max(uResolution.x/max(uResolution.y,1.0),.3);
    vec2 scr=vec2(world.x*focal/aspect,world.y*focal*.72-.035);
    gl_Position=vec4(scr,0.0,1.0);
    vNormal=normal;vWorld=world;vAlong=along;vCable=id;
})GLSL";

const char* kFragmentShader = R"GLSL(#version 410 core
in vec3 vNormal;
in vec3 vWorld;
in float vAlong;
in float vCable;
out vec4 fragColor;

uniform float uTime;
uniform float uLightPhase; // accumulated phase; slider 0 = paused, 1 = 100% speed
uniform float uLightPower;
uniform int uLightMode;
// Reflejo equirectangular de una imagen 2D de entorno sobre los tubos 3D.
uniform sampler2D uEnvironmentMap;
uniform float uEnvironmentReady;
uniform float uEnvironmentStrength;

float pulse(float d, float width) {
    return exp(-(d*d) / max(width*width, 0.00001));
}
float hash1(float n) { return fract(sin(n*83.473) * 43758.5453123); }

void main() {
    float t = uLightPhase; // smooth speed control, no jumps on changes
    float u = vAlong;
    float id = vCable;
    float light = 0.0;
    vec3 tint = vec3(0.88, 0.93, 1.0);

    if (uLightMode == 0) { // 1: barrido de fotones
        float x = fract(t*0.18 + id*0.037);
        light = pulse(u-x, 0.052) + 0.23*pulse(u-fract(x+0.21),0.09);
    } else if (uLightMode == 1) { // 2: pulsos secuenciales
        float x = fract(t*0.47 + u*3.7 - id*0.067);
        light = 0.2 + pow(max(0.0, 1.0-abs(x-0.5)*2.0), 5.0)*2.1;
    } else if (uLightMode == 2) { // 3: chispas electricas
        float band = floor(u*17.0 - t*0.85);
        float spark = hash1(id*17.7 + band*9.9);
        float coil = sin(u*116.0 - t*9.0 + id*13.0);
        light = 0.10 + step(0.80, spark)*pow(max(0.0, coil), 15.0)*2.8;
        tint = vec3(0.58, 0.89, 1.0);
    } else if (uLightMode == 3) { // 4: estrobos alternados
        float gate = step(0.56, fract(t*1.90 + id*0.17));
        light = gate*(0.65+0.4*sin(u*25.0 + id));
    } else { // 5: puntos luminosos orbitales
        float p1 = fract(t*0.12 + hash1(id*7.0));
        float p2 = fract(0.9-t*0.18 + hash1(id*4.0));
        light = 1.7*pulse(u-p1, 0.025) + 1.5*pulse(u-p2, 0.018);
    }

    vec3 n = normalize(vNormal);
    float edge = pow(1.0-abs(dot(n,vec3(0.0,0.0,1.0))),2.0);
    float spec = pow(max(0.0, dot(reflect(normalize(vec3(-0.35,-0.8,-1.0)),n), vec3(0.0,0.0,1.0))), 14.0);
    float diffuse = 0.26 + 0.55*max(dot(n, normalize(vec3(-0.3,0.4,1.0))),0.0);
    float energy = (0.14 + 0.70*light) * (0.25 + uLightPower*2.5);
    vec3 metal = vec3(0.075, 0.088, 0.095) * diffuse;
    vec3 illuminated = tint * (energy*(0.48 + 0.52*diffuse + 0.45*edge) + 0.2*spec);
    vec3 original = metal + illuminated;
    vec3 shaded = original;
    if (uEnvironmentReady > .5 && uEnvironmentStrength > .00001) {
        // Reflexion sobre la normal del tubo. La imagen 01..50 no es un overlay 2D.
        vec3 eye = normalize(vec3(0.0, 0.0, 3.9) - vWorld);
        vec3 reflection = reflect(-eye,n);
        float longitude = atan(reflection.z, reflection.x) / 6.28318530718 + .5;
        float latitude = .5 - asin(clamp(reflection.y,-1.0,1.0)) / 3.14159265359;
        vec3 env = texture(uEnvironmentMap,vec2(longitude,latitude)).rgb;
        // La iluminacion animada original continua atravesando el reflejo.
        vec3 textured = original * (.43 + 1.50*env) + env*.20;
        shaded = mix(original, textured, clamp(uEnvironmentStrength,0.0,1.0));
    }
    fragColor = vec4(shaded, 1.0);
}
)GLSL";

class CABLESGenerator final : public CFFGLPlugin {
public:
    CABLESGenerator() : CFFGLPlugin(), start_(Clock::now()), last_(start_) {
        SetMinInputs(0);
        SetMaxInputs(0);
        values_[P_CABLE_COUNT] = .575f; // 0..80
        values_[P_CHAOS] = .50f;
        values_[P_LENGTH] = 1.0f;
        values_[P_SPREAD] = .67f;
        values_[P_THICKNESS] = .22f;
        values_[P_BUNCH] = .45f;
        values_[P_SLACK] = .39f;
        values_[P_ZOOM] = 0.0f;
        values_[P_RELEASE] = 0.0f;
        values_[P_SPHERE_DIAMETER] = .90f / 3.0f;
        values_[P_ROT_X] = 0.0f;
        values_[P_ROT_Y] = 0.0f;
        values_[P_ROT_Z] = 0.0f;
        values_[P_LIGHT_MODE] = 0.0f;
        values_[P_LIGHT_SPEED] = .50f;
        values_[P_LIGHT_POWER] = .60f;
        values_[P_ERR_AMOUNT] = .62f;
        values_[P_ERR_SPEED] = .52f;
        values_[P_ERR_JITTER] = .24f;
        values_[P_ERR_SPREAD] = .65f;
        values_[P_ERR_RANDOMNESS] = .87f;
        values_[P_ERR_SHARPNESS] = .75f;
        values_[P_ENV_SELECT] = 0.0f; // 00 = original, sin textura
        values_[P_ENV_STRENGTH] = .55f;
        SetParamInfo(P_CABLE_COUNT,"Cantidad",FF_TYPE_STANDARD,values_[P_CABLE_COUNT]);
        SetParamInfo(P_CHAOS,"Caos amplitud",FF_TYPE_STANDARD,values_[P_CHAOS]);
        SetParamInfo(P_LENGTH,"Largo cables",FF_TYPE_STANDARD,values_[P_LENGTH]);
        SetParamInfo(P_SPREAD,"Apertura",FF_TYPE_STANDARD,values_[P_SPREAD]);
        SetParamInfo(P_THICKNESS,"Grosor 5x",FF_TYPE_STANDARD,values_[P_THICKNESS]);
        SetParamInfo(P_BUNCH,"Racimos",FF_TYPE_STANDARD,values_[P_BUNCH]);
        SetParamInfo(P_SLACK,"Curvatura 2x",FF_TYPE_STANDARD,values_[P_SLACK]);
        SetParamInfo(P_ZOOM,"Zoom interior",FF_TYPE_STANDARD,values_[P_ZOOM]);
        SetParamInfo(P_RELEASE,"Soltar / esfera",FF_TYPE_BOOLEAN,false);
        SetParamInfo(P_SPHERE_DIAMETER,"Diametro esfera",FF_TYPE_STANDARD,values_[P_SPHERE_DIAMETER]);
        SetParamInfo(P_ROT_X,"Rotacion X",FF_TYPE_STANDARD,values_[P_ROT_X]);
        SetParamInfo(P_ROT_Y,"Rotacion Y",FF_TYPE_STANDARD,values_[P_ROT_Y]);
        SetParamInfo(P_ROT_Z,"Rotacion Z",FF_TYPE_STANDARD,values_[P_ROT_Z]);
        SetOptionParamInfo(P_LIGHT_MODE,"Iluminacion FX",5,0.0f);
        const char* fx[]={"Barrido","Pulsos","Electricidad","Estrobo","Constelacion"};
        for(unsigned int i=0;i<5;++i)SetParamElementInfo(P_LIGHT_MODE,i,fx[i],static_cast<float>(i));
        SetParamInfo(P_LIGHT_SPEED,"Velocidad luz",FF_TYPE_STANDARD,values_[P_LIGHT_SPEED]);
        SetParamInfo(P_LIGHT_POWER,"Intensidad luz",FF_TYPE_STANDARD,values_[P_LIGHT_POWER]);
        SetParamInfo(P_ERR_AMOUNT,"Erratic Amount",FF_TYPE_STANDARD,values_[P_ERR_AMOUNT]);
        SetParamInfo(P_ERR_SPEED,"Erratic Speed",FF_TYPE_STANDARD,values_[P_ERR_SPEED]);
        SetParamInfo(P_ERR_JITTER,"Erratic Jitter",FF_TYPE_STANDARD,values_[P_ERR_JITTER]);
        SetParamInfo(P_ERR_SPREAD,"Erratic Spread",FF_TYPE_STANDARD,values_[P_ERR_SPREAD]);
        SetParamInfo(P_ERR_RANDOMNESS,"Erratic Random",FF_TYPE_STANDARD,values_[P_ERR_RANDOMNESS]);
        SetParamInfo(P_ERR_SHARPNESS,"Sharpness",FF_TYPE_STANDARD,values_[P_ERR_SHARPNESS]);
        // Carpeta vacia: busca CABLES_Texturas al lado del DLL.
        // Se permite una ruta absoluta en la caja de texto de Resolume.
        SetParamInfo(P_ENV_FOLDER,"Carpeta entorno",FF_TYPE_TEXT,0.0f);
        SetOptionParamInfo(P_ENV_SELECT,"Textura entorno",51,0.0f);
        SetParamElementInfo(P_ENV_SELECT,0,"00 - Sin textura",0.0f);
        for(unsigned int i=1;i<=50;++i) {
            char label[32];
            std::snprintf(label,sizeof(label),"%02u",i);
            SetParamElementInfo(P_ENV_SELECT,i,label,static_cast<float>(i));
        }
        SetParamInfo(P_ENV_STRENGTH,"Intensidad entorno",FF_TYPE_STANDARD,values_[P_ENV_STRENGTH]);
    }

    FFResult InitGL(const FFGLViewportStruct* vp) override {
        if (!shader_.Compile(kVertexShader, kFragmentShader)) return FF_FAIL;
        glGenVertexArrays(1, &vao_);
        if (!vao_) { shader_.FreeGLResources(); return FF_FAIL; }
        return CFFGLPlugin::InitGL(vp);
    }

    FFResult DeInitGL() override {
        if(envTexture_!=0){glDeleteTextures(1,&envTexture_);envTexture_=0;}
        if (vao_ != 0) { glDeleteVertexArrays(1,&vao_); vao_=0; }
        shader_.FreeGLResources();
        return FF_SUCCESS;
    }

    FFResult SetFloatParameter(unsigned int index, float value) override {
        if (index >= P_COUNT) return FF_FAIL;
        if (index == P_ENV_FOLDER) return FF_FAIL; // entrada de texto, no slider
        if (index == P_ENV_SELECT) {
            const float next = std::max(0.0f, std::min(value, 50.0f));
            if (std::lround(next)!=std::lround(values_[index])) needsEnvironmentReload_=true;
            values_[index]=next;
        }
        else if (index == P_RELEASE) values_[index] = value >= 0.5f ? 1.0f : 0.0f;
        else if (index == P_LIGHT_MODE) values_[index] = std::max(0.0f, std::min(value, 4.0f));
        else values_[index] = std::max(0.0f, std::min(value, 1.0f));
        return FF_SUCCESS;
    }

    float GetFloatParameter(unsigned int index) override {
        return index < P_COUNT && index != P_ENV_FOLDER ? values_[index] : 0.0f;
    }

    FFResult SetTextParameter(unsigned int index, const char* value) override {
        if(index!=P_ENV_FOLDER) return FF_FAIL;
        std::string next = value == nullptr ? "" : value;
        if(next!=environmentFolder_) {environmentFolder_=std::move(next);needsEnvironmentReload_=true;}
        return FF_SUCCESS;
    }
    char* GetTextParameter(unsigned int index) override {
        return index==P_ENV_FOLDER ? const_cast<char*>(environmentFolder_.c_str()) : nullptr;
    }

    FFResult ProcessOpenGL(ProcessOpenGLStruct*) override {
        if (vao_ == 0 || !shader_.IsReady()) return FF_FAIL;
        auto now = Clock::now();
        float dt = std::chrono::duration<float>(now-last_).count();
        last_ = now;
        dt = std::max(0.0f, std::min(dt,0.1f));
        float target = values_[P_RELEASE];
        // Convergencia suave hacia el modo suspendido (y viceversa).
        // Release Speed is deliberately fixed to 0 internally.
        constexpr float kReleaseSpeed=0.0f;
        release_ += (target-release_) * (1.0f-std::exp(-dt*(.45f + 4.0f*kReleaseSpeed)));
        // Absolute sliders: 0..1 maps to 0..360 degrees, no accumulated velocity.
        angles_[0]=values_[P_ROT_X]*6.28318530718f;
        angles_[1]=values_[P_ROT_Y]*6.28318530718f;
        angles_[2]=values_[P_ROT_Z]*6.28318530718f;
        float time = std::chrono::duration<float>(now-start_).count();
        // 0% genuinely stops the light movement; higher settings advance
        // continuously, without the discontinuity of time * changing speed.
        lightPhase_ += dt * 4.0f * values_[P_LIGHT_SPEED];

        // Respect existing GL state: Resolume shares this context with other effects.
        GLint previousActiveTexture=0, previousTexture0=0;
        glGetIntegerv(GL_ACTIVE_TEXTURE,&previousActiveTexture);
        glActiveTexture(GL_TEXTURE0);
        glGetIntegerv(GL_TEXTURE_BINDING_2D,&previousTexture0);
        int selected=static_cast<int>(std::lround(values_[P_ENV_SELECT]));
        if(needsEnvironmentReload_ || selected!=loadedEnvironmentIndex_){
            reloadEnvironment(selected); // one active texture in GPU, never 50 at once
        }
        GLint prevVao=0, prevShader=0;
        GLfloat prevClear[4] = {};
        const GLboolean prevBlend=glIsEnabled(GL_BLEND);
        const GLboolean prevDepth=glIsEnabled(GL_DEPTH_TEST);
        const GLboolean prevCull=glIsEnabled(GL_CULL_FACE);
        glGetIntegerv(GL_VERTEX_ARRAY_BINDING,&prevVao);
        glGetIntegerv(GL_CURRENT_PROGRAM,&prevShader);
        glGetFloatv(GL_COLOR_CLEAR_VALUE,prevClear);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glClearColor(0.0f,0.0f,0.0f,0.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glUseProgram(shader_.GetGLID());
        shader_.Set("uTime",time);
        shader_.Set("uZoom",values_[P_ZOOM]);
        shader_.Set("uChaos",values_[P_CHAOS]);
        shader_.Set("uLength",values_[P_LENGTH]);
        shader_.Set("uBunch",values_[P_BUNCH]);
        shader_.Set("uSlack",2.0f*values_[P_SLACK]);
        shader_.Set("uSpread",values_[P_SPREAD]);
        shader_.Set("uThickness",values_[P_THICKNESS]);
        shader_.Set("uRelease",release_);
        shader_.Set("uSphereDiameter",3.0f*values_[P_SPHERE_DIAMETER]);
        shader_.Set("uAngleX", angles_[0]);
        shader_.Set("uAngleY", angles_[1]);
        shader_.Set("uAngleZ", angles_[2]);
        shader_.Set("uResolution",static_cast<float>(currentViewport.width),static_cast<float>(currentViewport.height));
        shader_.Set("uLightPhase",lightPhase_);
        shader_.Set("uLightPower",values_[P_LIGHT_POWER]);
        shader_.Set("uLightMode",static_cast<int>(std::floor(values_[P_LIGHT_MODE]+0.5f)));
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D,envTexture_);
        GLint envUniform=glGetUniformLocation(shader_.GetGLID(),"uEnvironmentMap");
        if(envUniform>=0) glUniform1i(envUniform,0);
        shader_.Set("uEnvironmentReady",envTexture_!=0?1.0f:0.0f);
        shader_.Set("uEnvironmentStrength",values_[P_ENV_STRENGTH]);
        shader_.Set("uErrAmount",values_[P_ERR_AMOUNT]);
        shader_.Set("uErrSpeed",values_[P_ERR_SPEED]);
        shader_.Set("uErrJitter",values_[P_ERR_JITTER]);
        shader_.Set("uErrSpread",values_[P_ERR_SPREAD]);
        shader_.Set("uErrRandomness",values_[P_ERR_RANDOMNESS]);
        shader_.Set("uErrSharpness",values_[P_ERR_SHARPNESS]);
        // v1.3.1: map the complete slider range to 0..80 instances.
        // gl_InstanceID is independent of this value: the original cables
        // never change coordinates when the user changes Cantidad.
        // With count==0, GL draws nothing; the RGBA buffer was already
        // cleared to transparent black at the beginning of this frame.
        const int count=static_cast<int>(std::lround(values_[P_CABLE_COUNT]*80.0f));
        glBindVertexArray(vao_);
        glDrawArraysInstanced(GL_TRIANGLES,0,kVerticesPerCable,count);

        glBindTexture(GL_TEXTURE_2D,static_cast<GLuint>(previousTexture0));
        glActiveTexture(static_cast<GLenum>(previousActiveTexture));
        glBindVertexArray(static_cast<GLuint>(prevVao));
        glUseProgram(static_cast<GLuint>(prevShader));
        glClearColor(prevClear[0],prevClear[1],prevClear[2],prevClear[3]);
        if (prevBlend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
        if (prevDepth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
        if (prevCull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
        return FF_SUCCESS;
    }

private:
    // WIC es parte de Windows: decodifica PNG/JPEG/BMP/TIFF sin bibliotecas DLL externas.
    // El plugin selecciona una imagen numerada, la decodifica solo al cambiar el selector
    // y la sube una sola vez a GPU (2D equirectangular de entorno).
    void reloadEnvironment(int index) {
        needsEnvironmentReload_=false;
        loadedEnvironmentIndex_=index;
        if(envTexture_) {glDeleteTextures(1,&envTexture_);envTexture_=0;}
        if(index<=0 || index>50) return;
#if defined(_WIN32)
        namespace fs=std::filesystem;
        const std::wstring directoryName=folderPath();
        if(directoryName.empty()) return;
        const fs::path dir(directoryName);
        wchar_t number[8]={};
        std::swprintf(number,8,L"%02d",index);
        const wchar_t* extensions[]={L".png",L".jpg",L".jpeg",L".bmp",L".tif",L".tiff"};
        for(const wchar_t* extension:extensions) {
            fs::path candidate = dir/(std::wstring(number)+extension);
            std::error_code ec;
            if(!fs::is_regular_file(candidate,ec)) continue;
            if(loadImageWIC(candidate.wstring())) break;
        }
#endif
    }
#if defined(_WIN32)
    static std::wstring utf8ToWide(const std::string& str){
        if(str.empty())return {};
        int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,str.c_str(),-1,nullptr,0);
        UINT codepage=CP_UTF8;
        if(n<=0){codepage=CP_ACP;n=MultiByteToWideChar(codepage,0,str.c_str(),-1,nullptr,0);}
        if(n<=0)return {};
        std::wstring w(static_cast<size_t>(n),L'\0');
        MultiByteToWideChar(codepage,0,str.c_str(),-1,w.data(),n);
        w.resize(static_cast<size_t>(n)-1);
        return w;
    }
    static std::filesystem::path moduleDirectory(){
        static int localStaticAnchor=0;
        HMODULE module=nullptr;
        if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|
            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&localStaticAnchor),&module))return {};
        std::wstring modulePath(32768,L'\0');
        DWORD count=GetModuleFileNameW(module,modulePath.data(),static_cast<DWORD>(modulePath.size()));
        if(count==0 || count>=modulePath.size())return {};
        modulePath.resize(count);
        return std::filesystem::path(modulePath).parent_path();
    }
    std::wstring folderPath()const{
        const std::filesystem::path base=moduleDirectory();
        if(environmentFolder_.empty())return (base/L"CABLES_Texturas").wstring();
        std::filesystem::path entered(utf8ToWide(environmentFolder_));
        if(entered.empty())return (base/L"CABLES_Texturas").wstring();
        return (entered.is_absolute()?entered:base/entered).wstring();
    }
    bool loadImageWIC(const std::wstring& fileName){
        using Microsoft::WRL::ComPtr;
        const HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
        struct COMScope {bool active;~COMScope(){if(active)CoUninitialize();}};
        COMScope comScope{SUCCEEDED(com)};
        ComPtr<IWICImagingFactory> factory;
        HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,
                                    IID_PPV_ARGS(factory.GetAddressOf()));
        if(FAILED(hr)) return false;
        ComPtr<IWICBitmapDecoder> decoder;
        hr=factory->CreateDecoderFromFilename(fileName.c_str(),nullptr,GENERIC_READ,
                                                WICDecodeMetadataCacheOnLoad,decoder.GetAddressOf());
        ComPtr<IWICBitmapFrameDecode> frame;
        if(SUCCEEDED(hr))hr=decoder->GetFrame(0,frame.GetAddressOf());
        UINT width=0,height=0;
        if(SUCCEEDED(hr))hr=frame->GetSize(&width,&height);
        if(FAILED(hr)||width==0||height==0)return false;
        ComPtr<IWICBitmapSource> source;
        if(width>4096 || height>2048){
            double scale=std::min(4096.0/width,2048.0/height);
            UINT w=std::max(1u,static_cast<UINT>(width*scale));
            UINT h=std::max(1u,static_cast<UINT>(height*scale));
            ComPtr<IWICBitmapScaler> scaler;
            hr=factory->CreateBitmapScaler(scaler.GetAddressOf());
            if(SUCCEEDED(hr))hr=scaler->Initialize(frame.Get(),w,h,WICBitmapInterpolationModeFant);
            if(SUCCEEDED(hr)){source=scaler;width=w;height=h;}
        }else {source=frame;}
        ComPtr<IWICFormatConverter> converted;
        if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(converted.GetAddressOf());
        if(SUCCEEDED(hr))hr=converted->Initialize(source.Get(),GUID_WICPixelFormat32bppRGBA,
                              WICBitmapDitherTypeNone,nullptr,0.0,WICBitmapPaletteTypeCustom);
        // Maximum is limited to 4096x2048x4 (~32MB) to avoid GPU memory spikes.
        std::vector<uint8_t> rgba;
        if(SUCCEEDED(hr)){
            rgba.resize(static_cast<size_t>(width)*height*4);
            hr=converted->CopyPixels(nullptr,width*4,static_cast<UINT>(rgba.size()),rgba.data());
        }
        if(FAILED(hr))return false;
        GLint oldPack=4;
        glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldPack);
        glPixelStorei(GL_UNPACK_ALIGNMENT,1);
        GLuint candidate=0;
        glGenTextures(1,&candidate);
        if(candidate){
            glBindTexture(GL_TEXTURE_2D,candidate);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
            glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,rgba.data());
            glGenerateMipmap(GL_TEXTURE_2D);
        }
        glPixelStorei(GL_UNPACK_ALIGNMENT,oldPack);
        envTexture_=candidate;
        return candidate!=0;
    }
#else
    // Offline GLSL tests use a Linux OpenGL driver; the production DLL uses WIC on Windows.
#endif
    using Clock = std::chrono::steady_clock;
    Clock::time_point start_, last_;
    FFGLShader shader_;
    GLuint vao_=0;
    float values_[P_COUNT]={};
    float release_=0.0f;
    float angles_[3]={0.0f,0.0f,0.0f};
    float lightPhase_=0.0f;
    std::string environmentFolder_; // empty: ./CABLES_Texturas relative to DLL
    GLuint envTexture_=0;
    int loadedEnvironmentIndex_=-1;
    bool needsEnvironmentReload_=true;
};

static CFFGLPluginInfo pluginInfo(
    PluginFactory<CABLESGenerator>,
    "CB17", "CABLES", 2, 1, 1, 7, FF_SOURCE,
    "CABLES: texturas entorno 01..50, intensidad, geometria y movimientos v1.6.",
    "MB Studio / FFGL generador para Resolume Arena"
);
} // namespace
