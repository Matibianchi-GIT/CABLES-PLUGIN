# CABLES v1.7 — Texturas de entorno

- `Carpeta entorno`: campo de texto para ruta absoluta; vacío utiliza `CABLES_Texturas` al lado del DLL.
- `Textura entorno`: selector `00` (apagado), `01`…`50`.
- `Intensidad entorno`: slider 0%–100%, 0 deja el shader original sin alteraciones.
- Carga WIC nativa de Windows: PNG, JPG, JPEG, BMP, TIFF; redimensiona si supera 4096×2048.
- Reflejo tipo environment mapping equirectangular sobre tubos, afectado por orientación XYZ, compatible con los 5 FX de iluminación.
- Guarda solo una textura seleccionada en GPU. Al cambiar selección o carpeta reemplaza textura.
- Carpetas vacías o faltantes no interrumpen el generador.
- Preserva geometría y controles de v1.6; nueva identificación FFGL CB17.
- No se ha compilado DLL real de Windows ni probado en Resolume; tests de shaders son OpenGL Linux.
