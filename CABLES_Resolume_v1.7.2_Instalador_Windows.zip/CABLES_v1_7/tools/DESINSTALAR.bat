@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$docs=[Environment]::GetFolderPath('MyDocuments'); $paths=@((Join-Path $docs 'Resolume\Extra Effects\CABLES.dll'),(Join-Path $docs 'Resolume Arena\Extra Effects\CABLES.dll')); foreach($dest in $paths){if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force; Write-Host ('Desinstalado: '+$dest)}}; Write-Host 'Las carpetas CABLES_Texturas no se borran.'"
pause
