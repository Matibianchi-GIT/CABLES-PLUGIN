﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$SoloCopiarDLL,
    [switch]$NoDescargarHerramientas
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$plugin = Join-Path $root 'dist\CABLES.dll'
$log = Join-Path $root 'INSTALACION_LOG.txt'
# Primero usar una carpeta FFGL de Resolume existente para no duplicar instalaciones.
$documents = [Environment]::GetFolderPath('MyDocuments')
$candidates = @((Join-Path $documents 'Resolume\Extra Effects'), (Join-Path $documents 'Resolume Arena\Extra Effects'))
$target = $candidates[0]
# Prioridad: actualizar la instalacion existente del plugin antes que crear otra.
$foundExisting = $false
foreach ($candidate in $candidates) {
    if(Test-Path -LiteralPath (Join-Path $candidate 'CABLES.dll')) {$target=$candidate;$foundExisting=$true;break}
}
if(-not $foundExisting) {
    foreach ($candidate in $candidates) {if(Test-Path -LiteralPath $candidate){$target=$candidate;break}}
}
$destination = Join-Path $target 'CABLES.dll'

function Log([string]$message) {
    $entry = ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] ' + $message)
    Write-Host $entry
    Add-Content -LiteralPath $log -Value $entry -Encoding UTF8
}
function ErrorFatal([string]$message) { throw $message }
function Tool([string]$name,[string[]]$alternatives) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach($path in $alternatives) { if ($path -and (Test-Path -LiteralPath $path)) {return $path} }
    return $null
}
# Registra la salida REAL de MSVC, CMake, Git y vcpkg.
# v1.7 no registraba stderr/stdout, por eso el log solo mostraba "codigo 1".
function Run([string]$exe,[string[]]$argv,[switch]$EsCompilacion) {
    Log ('Ejecutar: ' + $exe + ' ' + ($argv -join ' '))
    $priorPreference = $ErrorActionPreference
    $exitCode = 999
    try {
        # PowerShell 5.1 convierte stderr nativo a ErrorRecord cuando Stop esta activo.
        # Capturar con Continue permite guardar los errores del compilador sin abortar el pipe.
        $ErrorActionPreference = 'Continue'
        & $exe @argv 2>&1 | ForEach-Object {
            $line = [string]$_
            Write-Host $line
            Add-Content -LiteralPath $log -Value $line -Encoding UTF8
            if ($EsCompilacion) {
                Add-Content -LiteralPath (Join-Path $root 'ERROR_COMPILACION_DETALLE.txt') -Value $line -Encoding UTF8
            }
        }
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $priorPreference
    }
    if ($exitCode -ne 0) {
        if ($EsCompilacion) { Log 'Detalles guardados en ERROR_COMPILACION_DETALLE.txt' }
        ErrorFatal ($exe + ' devolvio codigo ' + $exitCode)
    }
}
function InstallWinget([string]$id,[string[]]$extra) {
    $wg = Tool 'winget.exe' @()
    if(-not $wg) { ErrorFatal 'Falta winget (App Installer). Instala Git, CMake y Visual Studio 2022 Build Tools con C++ desde sus paginas oficiales.' }
    $args = @('install','--id',$id,'-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--disable-interactivity') + $extra
    Run $wg $args
}
function FindVS() {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if(-not (Test-Path $vswhere)) { return $null }
    $path = (& $vswhere -version '[17.0,18.0)' -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath | Select-Object -First 1)
    if($path) { return $path }
    return $null
}
function HasDLLX64([string]$filename) {
    if(-not (Test-Path -LiteralPath $filename)) {return $false}
    $bytes = [IO.File]::ReadAllBytes($filename)
    if($bytes.Length -lt 2048 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90){return $false}
    $offset = [BitConverter]::ToInt32($bytes,0x3c)
    if($offset -lt 64 -or $offset + 6 -ge $bytes.Length){return $false}
    return ([BitConverter]::ToUInt16($bytes,$offset+4) -eq 0x8664)
}

try {
    Set-Content -LiteralPath $log -Value 'CABLES 1.7.2 - CABECERAS WINDOWS/WIC + LOG COMPLETO' -Encoding UTF8
    $detail = Join-Path $root 'ERROR_COMPILACION_DETALLE.txt'
    if(Test-Path -LiteralPath $detail){Remove-Item -LiteralPath $detail -Force}
    if([Environment]::Is64BitOperatingSystem -ne $true) { ErrorFatal 'Se necesita Windows x64.' }
    if($env:OS -ne 'Windows_NT') { ErrorFatal 'El instalador debe ejecutarse en Windows.' }
    Log 'Inicio: generador FFGL CB17, correccion inclusiones Windows SDK de CABLES v1.7.2.'
    Log ('Destino: ' + $destination)
    $running = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'Resolume Arena*' }
    if($running) { ErrorFatal 'Cierra Resolume Arena antes de actualizar el plugin. No se cerrara automaticamente.' }

    if(-not (HasDLLX64 $plugin)) {
        if($SoloCopiarDLL){ ErrorFatal ('No hay un DLL Windows x64 compilado en ' + $plugin) }
        Log 'DLL aun no compilado: se preparara compilacion automatica.'
        $git = Tool 'git.exe' @("$env:ProgramFiles\Git\cmd\git.exe", "${env:ProgramFiles(x86)}\Git\cmd\git.exe")
        $cmake = Tool 'cmake.exe' @("$env:ProgramFiles\CMake\bin\cmake.exe")
        $vs = FindVS
        if(-not $NoDescargarHerramientas) {
            if(-not $git){ Log 'Git no detectado. Descargando con winget.'; InstallWinget 'Git.Git' @('--silent') }
            if(-not $cmake){ Log 'CMake no detectado. Descargando con winget.'; InstallWinget 'Kitware.CMake' @('--silent') }
            if(-not $vs){
                Log 'Visual Studio 2022 C++ Build Tools no detectado. Instalando (requiere espacio libre, autorizacion UAC e Internet).'
                InstallWinget 'Microsoft.VisualStudio.2022.BuildTools' @('--override','--passive --wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended')
            }
        }
        $git = Tool 'git.exe' @("$env:ProgramFiles\Git\cmd\git.exe", "${env:ProgramFiles(x86)}\Git\cmd\git.exe")
        $cmake = Tool 'cmake.exe' @("$env:ProgramFiles\CMake\bin\cmake.exe")
        $vs = FindVS
        if(-not $git -or -not $cmake -or -not $vs) {
            ErrorFatal 'No se pudieron preparar Git, CMake y Visual Studio 2022 Build Tools C++. Pueden requerirse reinicio y volver a ejecutar INSTALAR.bat.'
        }

        $ffgl = Join-Path $root 'vendor\ffgl'
        if(-not (Test-Path (Join-Path $ffgl 'CMakeLists.txt'))) {
            New-Item -ItemType Directory -Path (Split-Path $ffgl) -Force | Out-Null
            Run $git @('clone','--depth','1','https://github.com/resolume/ffgl.git',$ffgl)
        }
        $vcpkg = Join-Path $root 'vendor\vcpkg'
        if(-not (Test-Path (Join-Path $vcpkg 'bootstrap-vcpkg.bat'))) {
            Run $git @('clone','--depth','1','https://github.com/microsoft/vcpkg.git',$vcpkg)
        }
        $vcpkgExe = Join-Path $vcpkg 'vcpkg.exe'
        if(-not (Test-Path $vcpkgExe)) {
            Run (Join-Path $vcpkg 'bootstrap-vcpkg.bat') @('-disableMetrics')
        }
        Run $vcpkgExe @('install','glew:x64-windows-static','--disable-metrics')
        $toolchain = Join-Path $vcpkg 'scripts\buildsystems\vcpkg.cmake'
        $build = Join-Path $root 'build'
        Run $cmake @('-S',$root,'-B',$build,'-G','Visual Studio 17 2022','-A','x64',("-DCMAKE_TOOLCHAIN_FILE=" + $toolchain),'-DVCPKG_TARGET_TRIPLET=x64-windows-static','-DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded')
        Run $cmake @('--build',$build,'--config','Release','--target','CABLES','--parallel','4') -EsCompilacion
    }
    if(-not (HasDLLX64 $plugin)){ ErrorFatal ('La compilacion no genero un DLL x64 valido: ' + $plugin) }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    if(Test-Path $destination){
        $backupFolder = Join-Path $root 'backup'
        New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
        $backup = Join-Path $backupFolder ('CABLES_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.dll')
        Copy-Item -LiteralPath $destination -Destination $backup
        Log ('Respaldo: ' + $backup)
    }
    Copy-Item -LiteralPath $plugin -Destination $destination -Force
    if(-not (HasDLLX64 $destination)){ ErrorFatal 'Error al verificar el DLL copiado.' }
    # Nunca borrar ni sobrescribir imagenes anteriores del usuario.
    $texturesDir = Join-Path $target 'CABLES_Texturas'
    New-Item -ItemType Directory -Path $texturesDir -Force | Out-Null
    $helpFile = Join-Path $texturesDir 'LEEME.txt'
    if(-not (Test-Path -LiteralPath $helpFile)) {
        Copy-Item -LiteralPath (Join-Path $root 'CABLES_Texturas\LEEME.txt') -Destination $helpFile
    }
    Log ('Carpeta de texturas disponible: ' + $texturesDir)
    Log ('INSTALACION OK: ' + $destination)
    Log 'Reinicia Resolume Arena y busca CABLES en Sources (Generadores).'
} catch {
    Log ('ERROR: ' + $_.Exception.Message)
    exit 1
}
exit 0
