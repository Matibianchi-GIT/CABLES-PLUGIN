# CABLES v1.5 — Cambios y controles

Se parte de **MB Cable Anchors v1.4**, manteniendo el generador FFGL, los identificadores estables por cable, las rotaciones absolutas 0–360° en XYZ, los cuatro modos de movimiento y los cinco efectos de luz.

## Cambios solicitados

| Control | Resultado |
|---|---|
| Nombre de plugin | **CABLES**, DLL `CABLES.dll`, FFGL ID `CB15` |
| Burst Power, Auto Burst, Burst Trigger | Eliminados del panel y del shader |
| BPM luz | Reemplazado por slider **Velocidad luz** de 0 a 100% |
| Velocidad luz 0% | Congela la fase de los efectos sin cambiar su aspecto |
| Diámetro esfera | 0–300%; con 0 y liberación completa, geometría invisible, aun con Erratic activo |
| Erratic Bend | Fijo en 1.0 (9 segmentos de quiebre por tramo); sin slider |
| Velocidad soltar | Fija en 0.0; sin slider (suavizado interno conservado) |
| Anclajes | Fijos en 0.0; sin slider; puntos intermedios se interpolan de extremos |

## Controles restantes (27)

Cantidad, Caos amplitud, Noise, Jitter, Sinusoide, Length Origin, Largo cables, Apertura, Grosor 5x, Racimos, Curvatura 2x, Zoom interior, Soltar / esfera, Diámetro esfera, Rotación X, Rotación Y, Rotación Z, Iluminación FX, Velocidad luz, Intensidad luz, Motion Mode, Erratic Amount, Erratic Speed, Erratic Jitter, Erratic Spread, Erratic Random, Sharpness.

## Notas de implementación

- Slider velocidad luz 0–1 controla una fase acumulada con velocidad máxima de 4 unidades por segundo. Al llevarlo a 0 se detiene; al aumentar vuelve a avanzar sin saltos.
- El diámetro es un factor de 0.0 a 3.0 del radio de referencia de la esfera. En transición, las deformaciones Erratic y el grosor tubular convergen con el diámetro.
- «Anclajes = 0» elimina el desplazamiento estructural de los puntos intermedios, pero conserva puntos de apoyo matemáticos para mantener la continuidad de la curva.
- El valor «Velocidad soltar = 0» conserva la transición exponencial mínima que tenía el plugin original: coeficiente de 0.45 s⁻¹.
- La velocidad de luz afecta solo iluminación; los movimientos de los cables siguen controlados por sus parámetros.

## Validación y límites

Pruebas reproducibles dentro de `tests/`: compilación/enlace de shaders OpenGL, capturas de estados, prueba de transparencia. El compilador de Windows y el host Resolume no están disponibles en este entorno; por eso el archivo ZIP contiene el proyecto y el instalador de compilación, no un DLL precompilado.
