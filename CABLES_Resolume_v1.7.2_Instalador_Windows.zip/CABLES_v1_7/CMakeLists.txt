cmake_minimum_required(VERSION 3.21)
project(CABLES VERSION 1.7.0 LANGUAGES CXX)

if(NOT WIN32)
    message(FATAL_ERROR "Este FFGL se compila para Windows x64. En otros sistemas usa solo las pruebas GLSL.")
endif()
if(NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
    message(FATAL_ERROR "Se requiere un compilador de 64 bits (x64).")
endif()

# Dependencias vinculadas estaticamente para que el DLL final no requiera
# instalar VC++ Redistributable/GLEW al reproducir en Resolume.
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
add_compile_definitions(GLEW_STATIC)

if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/vendor/ffgl/CMakeLists.txt")
    message(FATAL_ERROR "Falta SDK FFGL en vendor/ffgl. Ejecuta INSTALAR.bat.")
endif()
find_package(OpenGL REQUIRED)
find_package(GLEW REQUIRED)
set(FFGL_BUILD_EXAMPLE_PLUGINS OFF CACHE BOOL "" FORCE)
add_subdirectory(vendor/ffgl EXCLUDE_FROM_ALL)
add_library(CABLES SHARED src/CABLES.cpp)
target_link_libraries(CABLES PRIVATE ffgl::sdk GLEW::GLEW OpenGL::GL ole32 windowscodecs)
set_target_properties(CABLES PROPERTIES
    PREFIX ""
    OUTPUT_NAME "CABLES"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/dist"
    RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_CURRENT_SOURCE_DIR}/dist"
    RUNTIME_OUTPUT_DIRECTORY_DEBUG "${CMAKE_CURRENT_SOURCE_DIR}/dist"
)
