@echo off
setlocal
chcp 65001 >nul
title CABLES v1.7.2 - instalador Windows Resolume Arena
cd /d "%~dp0"
echo.
echo  ========================================================
echo    CABLES v1.7.2 - FFGL RESOLUME ARENA - WINDOWS x64
echo  ========================================================
echo  Este programa instalara CABLES.dll. Si falta el DLL,
echo  lo compilara automaticamente con el SDK oficial.
echo  Primera ejecucion: puede requerir Internet, permiso de
echo  administrador y herramientas de Visual Studio C++.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Instalar.ps1"
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
 echo ERROR: revisar INSTALACION_LOG.txt
) else (
 echo CABLES instalado. Reinicia Resolume Arena.
)
pause
exit /b %EXITCODE%
