# CABLES v1.6.0 — Actualizacion de controles fijos

## Solicitud implementada

| Antes (v1.5) | Ahora (v1.6) |
|---|---|
| Noise / Jitter / Sinusoide: tres botones | Los tres activos siempre, directamente en GLSL; desaparecen los botones |
| Length Origin: Superior / Centro | Se fija **Centro**, sin control visible |
| Motion Mode: Stable / Vibrate / Erratic / Hybrid | Se fija **Vibrate**, sin control visible |

**Caos amplitud** sigue modulando simultaneamente los tres estilos; al 0% la deformacion adicional producida por Caos tiene amplitud cero, sin que se desactiven los algoritmos internamente. **Erratic Amount / Speed / Jitter / Spread / Random / Sharpness** siguen disponibles y deforman la geometria en modo Vibrate.

## Parametros visibles (orden de Resolume)
1. Cantidad (0–80)
2. Caos amplitud
3. Largo cables (siempre crece desde el centro)
4. Apertura
5. Grosor 5x
6. Racimos
7. Curvatura 2x
8. Zoom interior
9. Soltar / esfera
10. Diametro esfera (0–300%)
11. Rotacion X (0–360°)
12. Rotacion Y (0–360°)
13. Rotacion Z (0–360°)
14. Iluminacion FX (5 efectos)
15. Velocidad luz (0–100%)
16. Intensidad luz
17. Erratic Amount
18. Erratic Speed
19. Erratic Jitter
20. Erratic Spread
21. Erratic Random
22. Sharpness

## Implementacion
- Los uniformes `uNoiseOn`, `uJitterOn`, `uSineOn`, `uLengthOrigin` y `uMotionMode` se eliminaron del vertex shader.
- Los indices de parametros FFGL correspondientes se eliminaron del enum, del panel, del manejo de valores y del envio de uniformes.
- Las tres contribuciones (fBm noise, jitter de pasos y oscilacion sinusoidal) se suman siempre a `motion` y se escalan con `uChaos`.
- El calculo de longitud es `visibleU=0.5+(normalizedU-0.5)*uLength`, centrado para todo valor de largo.
- La vibracion sinusoidal se calcula sin condicional; en esfera permanece el aporte de vibracion.
- Se usa el ID FFGL `CB16` para evitar interpretar presets de 1.5 con indices de parametros cambiados.
- El DLL de salida sigue llamandose `CABLES.dll`, y el instalador respalda el archivo de igual nombre instalado previamente.

## Pruebas locales
`tests/validar_v16.py` compila y linkea GLSL en Mesa OpenGL 4.5 mediante EGL (requiere Python/Pillow, libEGL y libGL).
`clang++ -std=c++17 -fsyntax-only -I tests src/CABLES.cpp` comprueba sintaxis usando un stub de FFGLSDK solo para pruebas.

Estas pruebas no sustituyen la compilacion real de FFGL en Windows ni una prueba en Resolume Arena.
