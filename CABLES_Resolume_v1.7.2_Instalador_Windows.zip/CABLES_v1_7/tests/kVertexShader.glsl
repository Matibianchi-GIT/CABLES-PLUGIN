#version 410 core
// CABLES v1.7.0 — stable cable IDs; anchored fBm turbulence; XYZ scene rotation.
uniform float uTime;
uniform float uZoom;
uniform float uSpread;
uniform float uThickness; // 0..1 maps original tube radius up to 5x
uniform float uRelease;
uniform float uSphereDiameter; // 0..3.0; zero collapses entire released structure
uniform float uAngleX;     // accumulated radians, continuous across slider changes
uniform float uAngleY;
uniform float uAngleZ;
uniform float uLength;     // 0..1; zero hides ALL cable geometry
uniform float uChaos; // moving noise amplitude 0..1
uniform float uBunch;
uniform float uSlack;
uniform vec2 uResolution;
// Motion Mode is permanently Vibrate (1), with additional Erratic deformation active.
uniform float uErrAmount;
uniform float uErrSpeed;
uniform float uErrJitter;
uniform float uErrSpread;
uniform float uErrRandomness;
uniform float uErrSharpness;

out vec3 vNormal;
out vec3 vWorld;
out float vAlong;
out float vCable;

const float PI = 3.141592653589793;
const float TAU = 6.283185307179586;
const int SEG = 88;
const int SIDES = 6;
const float GOLDEN = 0.618033988749895;  // low-discrepancy distribution, independent of visible count
float hash1(float x) { return fract(sin(x*91.371)*47583.279); }

// Fast vector value noise: 3 independent channels, trilinearly interpolated.
// Coordinates contain persistent cable IDs, NOT the currently visible cable count.
vec3 hash33(vec3 p) {
    p=fract(p*vec3(.1031,.1030,.0973));
    p+=dot(p,p.yxz+33.33);
    return fract((p.xxy+p.yzz)*p.zyx);
}
vec3 valueNoise3(vec3 p) {
    vec3 i=floor(p), f=fract(p);
    f=f*f*(3.0-2.0*f);
    vec3 a=mix(hash33(i+vec3(0,0,0)),hash33(i+vec3(1,0,0)),f.x);
    vec3 b=mix(hash33(i+vec3(0,1,0)),hash33(i+vec3(1,1,0)),f.x);
    vec3 c=mix(hash33(i+vec3(0,0,1)),hash33(i+vec3(1,0,1)),f.x);
    vec3 d=mix(hash33(i+vec3(0,1,1)),hash33(i+vec3(1,1,1)),f.x);
    return mix(mix(a,b,f.y),mix(c,d,f.y),f.z)*2.0-1.0;
}
vec3 turbulence3(vec3 p) {
    // Two spatial frequencies generate different irregularities on each span.
    return .74*valueNoise3(p)+.26*valueNoise3(p*2.63+vec3(11.7,3.1,7.9));
}

vec3 rawAnchor(float id, int node) {
    // STABLE: IDs from 0..79 always map to the same points regardless of Quantity.
    // Additions are appended; no normalization by the current count.
    float q=fract((id+.5)*GOLDEN);
    float group=floor(id/6.0);
    float s=float(node);
    float span=mix(.42,1.70,uSpread);
    float cluster=(hash1(group*1.37+1.3)*2.0-1.0)*span;
    float ranked=(q*2.0-1.0)*span;
    float central=mix(ranked,cluster,uBunch*.77);
    float variation=hash1(id*3.731+s*17.713)-.5;
    float bundleWalk=(hash1(group*2.71+s*3.38)-.5)*.62*.70;
    float lateral=(hash1(id*1.331+s*9.191)-.5)*(.10+.78*.62);
    float xs=central+variation*(.1+uBunch*.12)+bundleWalk+lateral*(s>0.0?1.0:.27);
    float ys=1.30-s*.47+(hash1(id*2.93+s*6.23)-.5)*(.08+.22*.62);
    float zs=(hash1(group*.737+s*1.71)-.5)*.37+variation*(.08+.26*.62);
    if(node==4){
        // Full-length free tail; uLength controls the *visible fraction* of all spans.
        ys=-1.86+variation*.33;
        xs+=(hash1(id*4.97+14.0)-.5)*(.13+.75*.62);
        zs+=(hash1(id*7.73+15.0)-.5)*.34;
    }
    return vec3(xs,ys,zs);
}
vec3 anchor(float id, int node) {
    vec3 anchored=rawAnchor(id,node);
    if(node<=0 || node>=4) return anchored;
    vec3 top=rawAnchor(id,0),end=rawAnchor(id,4);
    float progress=float(node)*.25;
    vec3 fallback=mix(top,end,progress);
    // Anclajes = 0 fijo: los nodos intermedios siguen la linea superior-inferior.
    float influence=0.0;
    return mix(fallback,anchored,influence);
}
vec3 cableNetwork(float u, float id) {
    float scaled=clamp(u,0.0,1.0)*4.0;
    int seg=min(int(floor(scaled)),3);
    float t=scaled-float(seg);
    vec3 a=anchor(id,seg),b=anchor(id,seg+1);
    vec3 prev=anchor(id,max(seg-1,0)),next=anchor(id,min(seg+2,4));
    vec3 ta=(b-prev)*.42,tb=(next-a)*.42;
    float t2=t*t,t3=t2*t;
    vec3 p=(2.0*t3-3.0*t2+1.0)*a+(t3-2.0*t2+t)*ta
          +(-2.0*t3+3.0*t2)*b+(t3-t2)*tb;
    // Every intermediate anchor is fixed. Noise and vibration taper to exactly
    // zero at both ends of each individual segment.
    float envelope=sin(PI*t);
    float irregular=hash1(id*4.63+float(seg)*13.1);
    float sag=(.01+.47*uSlack)*(.34+irregular*.95);
    p.y-=envelope*sag;
    // Noise + Jitter + Sinusoide: los TRES se aplican siempre.
    // Caos amplitud conserva el control de la intensidad conjunta (0 desactiva amplitud).
    // La envolvente fija la deformacion a cero en los extremos de cada tramo.
    float phase=uTime*(0.38+hash1(id*2.13)*0.32);
    vec3 np=vec3(u*8.7+id*0.31,float(seg)*2.7+id*.07,phase);
    vec3 motion=turbulence3(np)*.92;
    float tick=floor(uTime*(7.0+17.0*hash1(id*5.7)));
    float knot=floor(t*9.0);
    motion+=(hash33(vec3(id*13.7+tick*1.93,knot*3.31,float(seg)*6.13))*2.0-1.0)*.75;
    float rate=1.2+hash1(id*1.17)*2.4;
    motion+=vec3(sin(uTime*rate+u*19.0+id),
                 sin(uTime*rate*.79+u*13.0+id*2.13),
                 sin(uTime*rate*1.37+u*17.0+id*5.71))*.68;
    p+=envelope*uChaos*motion;
    // Unpredictable wire loops at high Chaos settings.
    float loopMask=step(.47,irregular);
    float loopR=loopMask*(.06+.22*uSlack)*envelope;
    p.x+=loopR*(cos(TAU*t)-1.0)*.7;
    p.y+=loopR*sin(TAU*t);
    // Modo Vibrate fijo: vibracion orgánica sin selector de modo.
    // Los parametros Erratic siguen disponibles e independientes del modo fijo.
    float amp=(.008+.065*uErrAmount)*envelope;
    float vibrateRate=.6+5.0*uErrSpeed;
    p.x+=amp*sin(uTime*vibrateRate+u*11.0+id*.38);
    p.z+=amp*sin(uTime*vibrateRate*1.37+u*8.9+id*.27);
    return p;
}
vec3 rotateXYZ(vec3 p) {
    float x=cos(uAngleX),sx=sin(uAngleX);
    float y=cos(uAngleY),sy=sin(uAngleY);
    float z=cos(uAngleZ),sz=sin(uAngleZ);
    p=vec3(p.x,x*p.y-sx*p.z,sx*p.y+x*p.z);
    p=vec3(y*p.x+sy*p.z,p.y,-sy*p.x+y*p.z);
    p=vec3(z*p.x-sz*p.y,sz*p.x+z*p.y,p.z);
    return p;
}
vec3 cableSphere(float u,float id) {
    float q=fract((id+.5)*GOLDEN); // stable distribution at every count
    float theta=.16+(PI-.32)*u;
    float phi=q*TAU+uChaos*.35*sin(u*TAU*1.7+id*1.13);
    float radius=.86+uChaos*.12*sin(u*15.0+id*3.2)+uSlack*.05*sin(u*TAU*4.0+id);
    radius+=uErrAmount*.035*sin(uTime*2.1+u*27.0+id);
    // This is a geometry scale, not a camera zoom: only the sphere size changes.
    // Rotation is applied once after the network/sphere blend, in both modes.
    return uSphereDiameter*vec3(radius*sin(theta)*cos(phi),radius*cos(theta),radius*sin(theta)*sin(phi));
}
// Erratic movement: time-continuous random poses with angular interpolation.
// No dependencies on the active cable count. Every knot has a stable ID.
vec3 randomDirection(float key) {
    return vec3(hash1(key+1.31),hash1(key+19.71),hash1(key+53.13))*2.0-1.0;
}
vec3 erraticKnot(float id, int span, int node, int maxNode, float timePhase) {
    if(node<=0 || node>=maxNode) return vec3(0.0);
    float tick=floor(timePhase);
    float phase=fract(timePhase);
    // High Sharpness produces long holds followed by brief violent moves.
    float transition=smoothstep(mix(.08,.78,uErrSharpness),.997,phase);
    float key=id*173.31+float(span)*39.17+float(node)*8.57;
    vec3 previous=randomDirection(key+tick*211.73);
    vec3 next=randomDirection(key+(tick+1.0)*211.73);
    return mix(previous,next,transition);
}
vec3 erraticOffset(float along, float id, float released) {
    // Erratic parameters are active in ALL four motion modes.
    if(uErrAmount<=.00001) return vec3(0.0);
    float phaseAlong=clamp(along,0.0,.999999)*4.0;
    int span=int(floor(phaseAlong));
    float local=fract(phaseAlong);
    const int nodeCount=9; // Erratic Bend fijo en 1.0 (maximo)
    float knotPosition=local*float(nodeCount);
    int a=min(int(floor(knotPosition)),nodeCount-1);
    float alpha=fract(knotPosition);
    float speed=mix(.12,4.5,uErrSpeed);
    float perCable=mix(1.0,.55+1.05*hash1(id*7.711+2.7),uErrRandomness);
    float timePhase=uTime*speed*perCable+id*4.17*uErrRandomness;
    vec3 k0=erraticKnot(id,span,a-1,nodeCount,timePhase);
    vec3 k1=erraticKnot(id,span,a,nodeCount,timePhase);
    vec3 k2=erraticKnot(id,span,a+1,nodeCount,timePhase);
    vec3 k3=erraticKnot(id,span,a+2,nodeCount,timePhase);
    vec3 angular=mix(k1,k2,alpha);
    float f2=alpha*alpha,f3=f2*alpha;
    vec3 curved=.5*((2.0*k1)+(-k0+k2)*alpha+
        (2.0*k0-5.0*k1+4.0*k2-k3)*f2+(-k0+3.0*k1-3.0*k2+k3)*f3);
    vec3 shape=mix(curved,angular,uErrSharpness);
    // Scaled envelope guarantees pinning at every intermediary anchor in network mode.
    float pinned=smoothstep(0.0,.08,local)*smoothstep(0.0,.08,1.0-local);
    float pinWeight=mix(pinned,1.0,clamp(released,0.0,1.0));
    float range=uErrAmount*mix(.075,1.80,uErrSpread)*pinWeight;
    vec3 displacement=shape*range;

    // Micro-jitter: three incommensurate frequencies, unique per cable.
    float jitterRate=mix(8.0,43.0,uErrSpeed);
    vec3 rapid=vec3(
        sin(uTime*jitterRate*(.78+hash1(id*3.0))+along*51.7+id*7.1),
        sin(uTime*jitterRate*(1.08+hash1(id*3.1))+along*68.3+id*3.9),
        sin(uTime*jitterRate*(1.37+hash1(id*3.2))+along*43.9+id*9.3));
    displacement+=rapid*(.095*uErrAmount*uErrJitter*pinWeight);

    return displacement;
}

vec3 cablePoint(float u,float id) {
    // Extent control: 0 => no cable; 1 => full anchored/spherical length.
    // The generator ALWAYS references the same full-length spline.
    // Crecimiento fijo desde el CENTRO: tramo visible [0.5-L/2, 0.5+L/2].
    // Largo 0 oculta los tubos; Largo 1 revela la curva completa.
    // Los IDs y puntos originales nunca dependen de Largo ni Cantidad.
    float normalizedU=clamp(u,0.0,1.0);
    float visibleU=0.5+(normalizedU-0.5)*uLength;
    vec3 anchored=cableNetwork(visibleU,id);
    // 0 = ungrouped, 1 = cable network fully gathered on the local central axis.
    anchored.xz *= 1.0-uBunch;
    vec3 sphere=cableSphere(visibleU,id);
    // Trailing ends free before middle anchors, upper anchors release last.
    float freeTail=(1.0-visibleU)*.20;
    float localRelease=smoothstep(0.0,.80,clamp(uRelease-freeTail,0.0,1.0));
    vec3 result=mix(anchored,sphere,localRelease);
    // Apply erratic motion after the network-to-sphere blend, keeping IDs fixed.
    // Single XYZ transform for network, sphere and transition, including jitter.
    // Keep raw anchor coordinates and cable IDs untouched by the rotation.
    // The erratic offsets must contract with the spherical formation,
    // otherwise Diameter=0 still leaves animated cables visible.
    float sphericalScale=mix(1.0,clamp(uSphereDiameter,0.0,1.0),localRelease);
    return rotateXYZ(result+erraticOffset(visibleU,id,localRelease)*sphericalScale);
}
void main() {
    int quadIndex=gl_VertexID/6;
    int tri=gl_VertexID%6;
    int segment=quadIndex/SIDES;
    int side=quadIndex%SIDES;
    int du=(tri==1||tri==4||tri==5)?1:0;
    int dv=(tri==2||tri==3||tri==5)?1:0;
    float along=float(segment+du)/float(SEG);
    float angle=float(side+dv)/float(SIDES)*TAU;
    float id=float(gl_InstanceID);
    // Zero is genuinely empty, not tiny tubes or remaining hanging tails.
    if(uLength<=.00001 || (uRelease>=.999999 && uSphereDiameter<=.000001)){
        gl_Position=vec4(3.0,3.0,0.0,1.0);
        vNormal=vec3(0,0,1);vWorld=vec3(0);vAlong=along;vCable=id;
        return;
    }
    vec3 p=cablePoint(along,id);
    float d=.0018;
    vec3 p0=cablePoint(max(0.0,along-d),id);
    vec3 p1=cablePoint(min(1.0,along+d),id);
    vec3 tangent=normalize(p1-p0+vec3(.000001));
    vec3 axis=cross(tangent,vec3(0,0,1));
    if(dot(axis,axis)<.000001)axis=vec3(1,0,0);
    axis=normalize(axis);
    vec3 second=normalize(cross(tangent,axis));
    vec3 normal=cos(angle)*axis+sin(angle)*second;
    float releaseOfPoint=smoothstep(0.0,.80,clamp(uRelease-(1.0-along)*.20,0.0,1.0));
    float sphereScale=mix(1.0,clamp(uSphereDiameter,0.0,1.0),releaseOfPoint);
    float radius=mix(.0022,.0205,uThickness*uThickness)*mix(1.0,5.0,uThickness)*smoothstep(0.0,.012,uLength)*sphereScale;
    vec3 world=p+normal*radius;
    float cameraZ=mix(3.90,0.38,uZoom);
    float distanceToEye=cameraZ-world.z;
    if(distanceToEye<=0.10){
        gl_Position=vec4(3.0,3.0,0.0,1.0);
        vNormal=normal;vWorld=world;vAlong=along;vCable=id;return;
    }
    float focal=3.55/distanceToEye;
    float aspect=max(uResolution.x/max(uResolution.y,1.0),.3);
    vec2 scr=vec2(world.x*focal/aspect,world.y*focal*.72-.035);
    gl_Position=vec4(scr,0.0,1.0);
    vNormal=normal;vWorld=world;vAlong=along;vCable=id;
}