"""CABLES v1.7 shaders offline EGL/Mesa (no prueba Resolume Windows)."""
import ctypes as C, pathlib, os
os.environ['EGL_PLATFORM']='surfaceless'
EGL=C.CDLL('libEGL.so.1'); GL=C.CDLL('libGL.so.1')
P=C.c_void_p; I=C.c_int; U=C.c_uint; S=C.c_char_p

def fn(lib,name, restype, args):
 f=getattr(lib,name); f.restype=restype; f.argtypes=args; return f
getdisplay=fn(EGL,'eglGetDisplay',P,[P]); initialize=fn(EGL,'eglInitialize',U,[P,C.POINTER(I),C.POINTER(I)])
bindapi=fn(EGL,'eglBindAPI',U,[U]);choose=fn(EGL,'eglChooseConfig',U,[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)])
context=fn(EGL,'eglCreateContext',P,[P,P,P,C.POINTER(I)]);makecurrent=fn(EGL,'eglMakeCurrent',U,[P,P,P,P]);pbuffer=fn(EGL,'eglCreatePbufferSurface',P,[P,P,C.POINTER(I)])
display=getdisplay(None); assert display
major=I(); minor=I(); assert initialize(display,C.byref(major),C.byref(minor)), 'EGL init'
assert bindapi(0x30A2)
attrs=(I*13)(0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3040,8,0x3033,1,0x3038)
conf=P();num=I();assert choose(display,attrs,C.byref(conf),1,C.byref(num)) and num.value>0
ctxattrs=(I*7)(0x3098,4,0x30FB,1,0x30FD,1,0x3038)
ctx=context(display,conf,None,ctxattrs);assert ctx
width,height=720,405
pbattrs=(I*5)(0x3057,width,0x3056,height,0x3038)
surf=pbuffer(display,conf,pbattrs);assert surf
assert makecurrent(display,surf,surf,ctx)
getString=fn(GL,'glGetString',S,[U]);print('GL_VERSION',getString(0x1F02))
createShader=fn(GL,'glCreateShader',U,[U]);shaderSource=fn(GL,'glShaderSource',None,[U,I,C.POINTER(S),P]);compileShader=fn(GL,'glCompileShader',None,[U]);getShaderiv=fn(GL,'glGetShaderiv',None,[U,U,C.POINTER(I)]);getShaderInfoLog=fn(GL,'glGetShaderInfoLog',None,[U,I,C.POINTER(I),P]);
createProgram=fn(GL,'glCreateProgram',U,[]);attachShader=fn(GL,'glAttachShader',None,[U,U]);linkProgram=fn(GL,'glLinkProgram',None,[U]);getProgramiv=fn(GL,'glGetProgramiv',None,[U,U,C.POINTER(I)]);getProgramInfoLog=fn(GL,'glGetProgramInfoLog',None,[U,I,C.POINTER(I),P]);
prog=createProgram();base=pathlib.Path(__file__).parent
for kind,filename in [(0x8B31,'kVertexShader.glsl'),(0x8B30,'kFragmentShader.glsl')]:
 source=(base/filename).read_bytes(); sh=createShader(kind); buf=S(source); shaderSource(sh,1,C.byref(buf),None); compileShader(sh)
 status=I();getShaderiv(sh,0x8B81,C.byref(status));
 if not status.value:
  log=C.create_string_buffer(10000);n=I();getShaderInfoLog(sh,10000,C.byref(n),log)
  raise RuntimeError(filename+' '+log.value.decode())
 print(filename,'OK');attachShader(prog,sh)
linkProgram(prog);status=I();getProgramiv(prog,0x8B82,C.byref(status));
if not status.value:
 log=C.create_string_buffer(10000);n=I();getProgramInfoLog(prog,10000,C.byref(n),log);raise RuntimeError('LINK: '+log.value.decode())
print('Program LINK OK')
# Dibujar la escena con los sliders por defecto, y luego con modo esfera.
useProgram=fn(GL,'glUseProgram',None,[U]); getUniformLocation=fn(GL,'glGetUniformLocation',I,[U,S]);uniform1f=fn(GL,'glUniform1f',None,[I,C.c_float]);uniform1i=fn(GL,'glUniform1i',None,[I,I]);uniform2f=fn(GL,'glUniform2f',None,[I,C.c_float,C.c_float]);genVAO=fn(GL,'glGenVertexArrays',None,[I,C.POINTER(U)]);bindVAO=fn(GL,'glBindVertexArray',None,[U]);viewport=fn(GL,'glViewport',None,[I,I,I,I]);clearColor=fn(GL,'glClearColor',None,[C.c_float]*4);clear=fn(GL,'glClear',None,[U]);draw=fn(GL,'glDrawArraysInstanced',None,[U,I,I,I]);finish=fn(GL,'glFinish',None,[])
readPixels=fn(GL,'glReadPixels',None,[I,I,I,I,U,U,P]);disable=fn(GL,'glDisable',None,[U])
vao=U();genVAO(1,C.byref(vao));bindVAO(vao);useProgram(prog);viewport(0,0,width,height);disable(0x0B71)
def setf(n,x):uniform1f(getUniformLocation(prog,n.encode()),x)
from PIL import Image

from PIL import ImageDraw,ImageFont
p=base
u0=dict(uTime=5.7,uSphereDiameter=1.0,uSpread=.78,uThickness=.4,uRelease=0.0,
    uAngleX=.0,uAngleY=.0,uAngleZ=.0,uLength=1.0,uLightPhase=5.0,uLightPower=.62,uZoom=0,
    uChaos=.5,uBunch=.40,uSlack=.75,
    uErrAmount=.65,uErrSpeed=.64,uErrJitter=.34,uErrSpread=.79,
    uErrRandomness=.84,uErrSharpness=.88)

def render(name,count=18,**kw):
    data={**u0,**kw}
    for key,val in data.items(): setf(key,float(val))
    uniform2f(getUniformLocation(prog,b'uResolution'),float(width),float(height))
    uniform1i(getUniformLocation(prog,b'uLightMode'),int(kw.get('uLightMode',1)))
    clearColor(0,0,0,0);clear(0x4000);draw(0x0004,0,88*6*6,count);finish()
    raw=C.create_string_buffer(width*height*4)
    readPixels(0,0,width,height,0x1908,0x1401,raw)
    img=Image.frombytes('RGBA',(width,height),raw.raw).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    img.save(p/name)
    count_px=sum(1 for a in img.getchannel('A').getdata() if a>0)
    print(name, 'visible=',count_px,flush=True)
    return img

p=base

# Validaciones de invariantes: los modos fijos no tienen indices, uniforms ni UI.
import re
cpp=(base.parent/'src'/'CABLES.cpp').read_text(encoding='utf-8')
for forbidden in ['P_NOISE_ON','P_JITTER_ON','P_SINE_ON','P_LENGTH_ORIGIN','P_MOTION_MODE',
                  'uNoiseOn','uJitterOn','uSineOn','uLengthOrigin','uMotionMode',
                  'SetOptionParamInfo(P_MOTION_MODE','SetOptionParamInfo(P_LENGTH_ORIGIN']:
    assert forbidden not in cpp, f'Control fijo todavia expuesto: {forbidden}'
assert 'float visibleU=0.5+(normalizedU-0.5)*uLength;' in cpp
assert 'motion+=vec3(sin(' in cpp and 'motion+=(' in cpp and 'vec3 motion=turbulence3(np)' in cpp
assert 'p.x+=amp*sin(uTime*vibrateRate' in cpp
assert '"CB17", "CABLES"' in cpp

blank=render('00_sin_cables.png',count=0)
assert blank.getchannel('A').getbbox() is None, 'Cantidad=0 deja pixeles'
short0=render('01_largo_cero.png',uLength=0)
assert short0.getchannel('A').getbbox() is None, 'Largo=0 deja pixeles'

# Todas las tres oscilaciones se calculan siempre. Caos determina su amplitud.
quiet=render('02_caos_0.png',uTime=2.1,uChaos=0,uErrAmount=0)
all3=render('03_tres_ruidos_activos.png',uTime=2.1,uChaos=.85,uErrAmount=0)
all3later=render('04_tres_ruidos_tiempo.png',uTime=4.7,uChaos=.85,uErrAmount=0)
assert quiet.getchannel('A').getbbox() is not None
assert quiet.tobytes()!=all3.tobytes(), 'El control Caos no cambia la imagen'
assert all3.tobytes()!=all3later.tobytes(), 'Los ruidos no cambian con el tiempo'

# Vibrate siempre activo: incluso Caos=Erratic=0 debe variar con uTime.
vib1=render('05_vibrate_t0.png',uTime=0,uChaos=0,uErrAmount=0,uLightPhase=4)
vib2=render('06_vibrate_t8.png',uTime=8,uChaos=0,uErrAmount=0,uLightPhase=4)
assert vib1.tobytes()!=vib2.tobytes(), 'Vibrate fijo no genera oscilacion'

# Erratic sigue teniendo efecto aunque Mode sea fijo y sin selector.
err=render('07_vibrate_erratic.png',uTime=2.1,uChaos=.85,uErrAmount=1,uErrJitter=1)
assert all3.tobytes()!=err.tobytes(), 'Erratic no altera el modo Vibrate'

# Centro visible por intervalos de longitud, sin selector de origen.
for length in [.2,.5,1.0]:
    cropped=render(f'08_centro_largo_{int(length*100)}.png',uLength=length,uTime=0,uChaos=0,uErrAmount=0)
    assert cropped.getchannel('A').getbbox() is not None

# Validacion de regresion.
sphere0=render('09_esfera_diametro_0.png',uRelease=1.0,uSphereDiameter=0,uErrAmount=1,uThickness=1,uChaos=1)
assert sphere0.getchannel('A').getbbox() is None, 'Esfera en 0 debe desaparecer'
sphere=render('10_esfera_visible.png',uRelease=1.0,uSphereDiameter=2.0,uErrAmount=.5)
assert sphere.getchannel('A').getbbox() is not None
zoom=render('11_zoom.png',uZoom=.65)
rot=render('12_rotacion_xyz.png',uAngleX=.66,uAngleY=1.25,uAngleZ=2.03)
assert zoom.getchannel('A').getbbox() is not None
assert rot.getchannel('A').getbbox() is not None
print('CABLES v1.7 – shader GL y pruebas de invariantes OK')

# v1.7 : probar mapa de entorno real como textura OpenGL sobre la geometria.
# El backend WIC de Windows se verifica por inspeccion (no hay host Windows aqui).
genTex=fn(GL,'glGenTextures',None,[I,C.POINTER(U)])
bindTex=fn(GL,'glBindTexture',None,[U,U])
activeTex=fn(GL,'glActiveTexture',None,[U])
texParam=fn(GL,'glTexParameteri',None,[U,U,I])
texImage=fn(GL,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P])
tex=U();genTex(1,C.byref(tex));activeTex(0x84C0);bindTex(0x0DE1,tex)
texParam(0x0DE1,0x2801,0x2601);texParam(0x0DE1,0x2800,0x2601)
texParam(0x0DE1,0x2802,0x2901);texParam(0x0DE1,0x2803,0x812F)
from PIL import Image
w,h=256,128
texim=Image.new('RGBA',(w,h))
pixels=texim.load()
for y in range(h):
 for x in range(w):
  # Equirectangular de prueba: franjas de color, no overlay.
  v=x/w
  if v<.34: pixels[x,y]=(240,40+int(30*y/h),25,255)
  elif v<.68: pixels[x,y]=(25,210,30+int(80*y/h),255)
  else: pixels[x,y]=(30,55,245,255)
texbuf=C.create_string_buffer(texim.tobytes());texImage(0x0DE1,0,0x8058,w,h,0,0x1908,0x1401,texbuf)
uniform1i(getUniformLocation(prog,b'uEnvironmentMap'),0)
setf('uEnvironmentReady',1)
setf('uEnvironmentStrength',0)
baseEnv=render('13_entorno_intensidad_0.png',uTime=2.7,uChaos=.28,uErrAmount=.3)
setf('uEnvironmentStrength',1)
strongEnv=render('14_entorno_intensidad_100.png',uTime=2.7,uChaos=.28,uErrAmount=.3)
assert baseEnv.tobytes()!=strongEnv.tobytes(), 'La textura de entorno no modifica la iluminacion'
assert baseEnv.getchannel('A').tobytes()==strongEnv.getchannel('A').tobytes(),'El entorno modifica incorrectamente la geometria/transparencia'
setf('uEnvironmentReady',0)
absentEnv=render('15_entorno_desactivado.png',uTime=2.7,uChaos=.28,uErrAmount=.3)
assert absentEnv.tobytes()==baseEnv.tobytes(),'Intensidad 0 no coincide con render original'
print('CABLES v1.7 – seleccion de entorno, intensidad y transparencia GLSL OK')
