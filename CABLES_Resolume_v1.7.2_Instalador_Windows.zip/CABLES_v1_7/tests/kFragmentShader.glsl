#version 410 core
in vec3 vNormal;
in vec3 vWorld;
in float vAlong;
in float vCable;
out vec4 fragColor;

uniform float uTime;
uniform float uLightPhase; // accumulated phase; slider 0 = paused, 1 = 100% speed
uniform float uLightPower;
uniform int uLightMode;
// Reflejo equirectangular de una imagen 2D de entorno sobre los tubos 3D.
uniform sampler2D uEnvironmentMap;
uniform float uEnvironmentReady;
uniform float uEnvironmentStrength;

float pulse(float d, float width) {
    return exp(-(d*d) / max(width*width, 0.00001));
}
float hash1(float n) { return fract(sin(n*83.473) * 43758.5453123); }

void main() {
    float t = uLightPhase; // smooth speed control, no jumps on changes
    float u = vAlong;
    float id = vCable;
    float light = 0.0;
    vec3 tint = vec3(0.88, 0.93, 1.0);

    if (uLightMode == 0) { // 1: barrido de fotones
        float x = fract(t*0.18 + id*0.037);
        light = pulse(u-x, 0.052) + 0.23*pulse(u-fract(x+0.21),0.09);
    } else if (uLightMode == 1) { // 2: pulsos secuenciales
        float x = fract(t*0.47 + u*3.7 - id*0.067);
        light = 0.2 + pow(max(0.0, 1.0-abs(x-0.5)*2.0), 5.0)*2.1;
    } else if (uLightMode == 2) { // 3: chispas electricas
        float band = floor(u*17.0 - t*0.85);
        float spark = hash1(id*17.7 + band*9.9);
        float coil = sin(u*116.0 - t*9.0 + id*13.0);
        light = 0.10 + step(0.80, spark)*pow(max(0.0, coil), 15.0)*2.8;
        tint = vec3(0.58, 0.89, 1.0);
    } else if (uLightMode == 3) { // 4: estrobos alternados
        float gate = step(0.56, fract(t*1.90 + id*0.17));
        light = gate*(0.65+0.4*sin(u*25.0 + id));
    } else { // 5: puntos luminosos orbitales
        float p1 = fract(t*0.12 + hash1(id*7.0));
        float p2 = fract(0.9-t*0.18 + hash1(id*4.0));
        light = 1.7*pulse(u-p1, 0.025) + 1.5*pulse(u-p2, 0.018);
    }

    vec3 n = normalize(vNormal);
    float edge = pow(1.0-abs(dot(n,vec3(0.0,0.0,1.0))),2.0);
    float spec = pow(max(0.0, dot(reflect(normalize(vec3(-0.35,-0.8,-1.0)),n), vec3(0.0,0.0,1.0))), 14.0);
    float diffuse = 0.26 + 0.55*max(dot(n, normalize(vec3(-0.3,0.4,1.0))),0.0);
    float energy = (0.14 + 0.70*light) * (0.25 + uLightPower*2.5);
    vec3 metal = vec3(0.075, 0.088, 0.095) * diffuse;
    vec3 illuminated = tint * (energy*(0.48 + 0.52*diffuse + 0.45*edge) + 0.2*spec);
    vec3 original = metal + illuminated;
    vec3 shaded = original;
    if (uEnvironmentReady > .5 && uEnvironmentStrength > .00001) {
        // Reflexion sobre la normal del tubo. La imagen 01..50 no es un overlay 2D.
        vec3 eye = normalize(vec3(0.0, 0.0, 3.9) - vWorld);
        vec3 reflection = reflect(-eye,n);
        float longitude = atan(reflection.z, reflection.x) / 6.28318530718 + .5;
        float latitude = .5 - asin(clamp(reflection.y,-1.0,1.0)) / 3.14159265359;
        vec3 env = texture(uEnvironmentMap,vec2(longitude,latitude)).rgb;
        // La iluminacion animada original continua atravesando el reflejo.
        vec3 textured = original * (.43 + 1.50*env) + env*.20;
        shaded = mix(original, textured, clamp(uEnvironmentStrength,0.0,1.0));
    }
    fragColor = vec4(shaded, 1.0);
}
