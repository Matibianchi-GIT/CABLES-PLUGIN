#pragma once
#include <cstdint>
using FFResult=int;
constexpr FFResult FF_SUCCESS=0, FF_FAIL=1;
constexpr unsigned int FF_TYPE_STANDARD=1,FF_TYPE_BOOLEAN=2,FF_SOURCE=3,FF_TYPE_TEXT=100;
using GLuint=unsigned int;using GLint=int;using GLsizei=int;using GLenum=unsigned int;using GLfloat=float;using GLboolean=unsigned char;
constexpr GLuint GL_BLEND=0,GL_DEPTH_TEST=1,GL_CULL_FACE=2,GL_VERTEX_ARRAY_BINDING=3,GL_CURRENT_PROGRAM=4,GL_COLOR_CLEAR_VALUE=5,GL_COLOR_BUFFER_BIT=6,GL_TRIANGLES=7,GL_TEXTURE_2D=8,GL_TEXTURE0=9,GL_ACTIVE_TEXTURE=10,GL_TEXTURE_BINDING_2D=11,GL_UNPACK_ALIGNMENT=12,GL_TEXTURE_MIN_FILTER=13,GL_TEXTURE_MAG_FILTER=14,GL_TEXTURE_WRAP_S=15,GL_TEXTURE_WRAP_T=16,GL_LINEAR_MIPMAP_LINEAR=17,GL_LINEAR=18,GL_REPEAT=19,GL_CLAMP_TO_EDGE=20,GL_RGBA8=21,GL_RGBA=22,GL_UNSIGNED_BYTE=23;
void glGenTextures(int,GLuint*);void glDeleteTextures(int,const GLuint*);void glActiveTexture(GLenum);void glBindTexture(GLenum,GLuint);void glPixelStorei(GLenum,int);void glTexParameteri(GLenum,GLenum,int);void glTexImage2D(GLenum,int,int,int,int,int,GLenum,GLenum,const void*);void glGenerateMipmap(GLenum);GLint glGetUniformLocation(GLuint,const char*);void glUniform1i(GLint,int);
void glGenVertexArrays(int,GLuint*);void glDeleteVertexArrays(int,GLuint*);GLboolean glIsEnabled(GLenum);
void glGetIntegerv(GLenum,GLint*);void glGetFloatv(GLenum,GLfloat*);void glDisable(GLenum);void glEnable(GLenum);
void glClearColor(float,float,float,float);void glClear(GLenum);void glUseProgram(GLuint);void glBindVertexArray(GLuint);void glDrawArraysInstanced(GLenum,int,int,int);
struct FFGLViewportStruct{int width,height;};struct ProcessOpenGLStruct{};
class CFFGLPlugin{
protected:FFGLViewportStruct currentViewport{};
public:CFFGLPlugin(bool =false){}virtual ~CFFGLPlugin()=default;
virtual FFResult InitGL(const FFGLViewportStruct* p){currentViewport=*p;return FF_SUCCESS;}
virtual FFResult DeInitGL(){return FF_SUCCESS;}
virtual FFResult ProcessOpenGL(ProcessOpenGLStruct*){return FF_FAIL;}
virtual FFResult SetFloatParameter(unsigned int,float){return FF_FAIL;}
virtual float GetFloatParameter(unsigned int){return 0;}
virtual FFResult SetTextParameter(unsigned int,const char*) {return FF_FAIL;}
virtual char* GetTextParameter(unsigned int){return nullptr;}
void SetMinInputs(unsigned int){}void SetMaxInputs(unsigned int){}
void SetParamInfo(unsigned int,const char*,unsigned int,float){}
void SetParamInfo(unsigned int,const char*,unsigned int,bool){}
void SetParamInfo(unsigned int,const char*,unsigned int,const char*){}
void SetOptionParamInfo(unsigned int,const char*,unsigned int,float){}
void SetParamElementInfo(unsigned int,unsigned int,const char*,float){}
};
namespace ffglex {class FFGLShader{public:bool Compile(const char*,const char*){return true;}void FreeGLResources(){}bool IsReady() const{return true;}GLuint GetGLID() const{return 1;}void Set(const char*,float){}void Set(const char*,int){}void Set(const char*,float,float){};};}
template<class T> CFFGLPlugin* PluginFactory(){return new T;}
struct CFFGLPluginInfo{template<typename F> CFFGLPluginInfo(F,const char*,const char*,int,int,int,int,int,const char*,const char*){}};
