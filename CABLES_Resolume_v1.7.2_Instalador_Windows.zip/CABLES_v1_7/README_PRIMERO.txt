CABLES v1.7 - FFGL para Resolume Arena 7 - Windows x64

CAMBIO: Texturas de entorno 01..50 y slider de intensidad 0..100%.
Se mantienen: Noise, Jitter y Sinusoide siempre activados; crecimiento centro;
Motion Mode Vibrate; geometria, luz, cantidad 0, diametro esfera 0 de v1.6.

INSTALACION:
1) Descomprimir TODO el ZIP.
2) Cerrar Resolume.
3) Ejecutar INSTALAR.bat. El instalador intenta preparar dependencias y compilar.
4) Reiniciar Resolume; buscar el generador CABLES en Sources / Generadores.
5) Copiar imagenes 01.png ... 50.png (o JPG/BMP/TIFF) a Documentos\Resolume\Extra Effects\CABLES_Texturas.
   Si Resolume usa 'Resolume Arena\Extra Effects', el instalador detecta esa carpeta existente.

PANEL:
- Carpeta entorno: texto opcional, ruta absoluta a una carpeta en Windows.
  Vacio = carpeta CABLES_Texturas instalada al lado de CABLES.dll.
- Textura entorno: 00 sin textura, 01..50 para elegir imagen numerada.
- Intensidad entorno: 0 conserva imagen original; 100 maxima influencia del entorno.

La imagen se interpreta como un entorno equirectangular reflectante sobre la
superficie de los cables; no es una imagen de fondo ni reemplaza la transparencia.
Formato recomendado 2:1, 2048x1024 o 4096x2048.

IMPORTANTE: paquete de codigo e INSTALADOR DE COMPILACION para Windows,
NO un DLL precompilado y probado en Resolume. La primera instalacion requiere
Internet y puede necesitar Visual Studio 2022 Build Tools, Git, CMake y GLEW.
El instalador respalda el DLL anterior y no borra las texturas del usuario.
Identificador de plugin CB17. Es posible que presets antiguos requieran ajustes.

CORRECCION 1.7.2: cabeceras de Windows/WIC movidas antes de FFGLSDK.h para resolver errores MSG/LPMSG/MultiByteToWideChar. Ver CORRECCION_COMPILACION_v1.7.2.txt.
